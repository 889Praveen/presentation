class SoftwareProject {
    private String requirements;
    private String design="skip";
    private String development;
    private String testing;
    private String deployment;

    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }

    public void setDesign(String design) {
        this.design = design;
    }

    public void setDevelopment(String development) {
        this.development = development;
    }

    public void setTesting(String testing) {
        this.testing = testing;
    }

    public void setDeployment(String deployment) {
        this.deployment = deployment;
    }

    public void showProject() {
        System.out.println("Software Project Details:");
        System.out.println("Requirements: " +requirements);
        System.out.println("Design: " + design);
        System.out.println("Implementation: " + development);
        System.out.println("Testing: " + testing);
        System.out.println("Deployment: " + deployment);
    }
}