
public class BuilderPatternDemo {
    public static void main(String[] args) {
        SDLCBuilder builder = new ConcreteSDLCBuilder();
        SDLCDirector director = new SDLCDirector(builder);
        SoftwareProject project = director.constructFullProjects();
        project.showProject();

    }
}