class SDLCDirector {
    private SDLCBuilder builder;

    public SDLCDirector(SDLCBuilder builder) {
        this.builder = builder;
    }


    public SoftwareProject constructFullProjects() {
        builder.setRequirements("Gather and analyze client requirements.");
        builder.setDesign("Create UML diagrams, architecture, and prototypes.");
        builder.setDevelopment("Code the application based on design.");
        builder.setTesting("Perform unit, integration, and system testing.");
        builder.setDeployment("Deploy the application to production.");
        return builder.build();
    }
    public SoftwareProject constructQuickProject() {
        builder.setRequirements("Gather and analyze client requirements.");
       
        builder.setDevelopment("Code the application based on design.");
        builder.setTesting("Perform unit, integration, and system testing.");
        builder.setDeployment("Deploy the application to production.");
        return builder.build();
    }

}
