class SoftwareProject {
    private String requirements;
    private String design;
    private String development;
    private String testing;
    private String deployment;

    public void setRequirements(String requirements) {
        this.requirements = requirements;
    }

    public void setDesign(String design) {
        this.design = design;
    }

    public void setDevelopment(String development) {
        this.development = development;
    }

    public void setTesting(String testing) {
        this.testing = testing;
    }

    public void setDeployment(String deployment) {
        this.deployment = deployment;
    }

    @Override
    public String toString() {
        return "SoftwareProject{" +
                "requirements='" + requirements + '\'' +
                ", design='" + design + '\'' +
                ", development='" + development + '\'' +
                ", testing='" + testing + '\'' +
                ", deployment='" + deployment + '\'' +
                '}';
    }
}