class SDLCDirector {
    private SDLCBuilder builder;

    public SDLCDirector(SDLCBuilder builder) {
        this.builder = builder;
    }


    public SoftwareProject constructProject() {
        builder.setRequirements("Gather and analyze client requirements.");
        builder.setDesign("Create UML diagrams, architecture, and prototypes.");
        builder.setDevelopment("Code the application based on design.");
        builder.setTesting("Perform unit, integration, and system testing.");
        builder.setDeployment("Deploy the application to production.");
        return builder.build();
    }
    public SoftwareProject withoutDesign() {
        builder.setRequirements("Gather and analyze client requirements.");
        builder.setDesign("Create UML diagrams, architecture, and prototypes.");
        builder.setDevelopment("Code the application based on design.");
        builder.setTesting("Perform unit, integration, and system testing.");
        builder.setDeployment("Deploy the application to production.");
        return builder.build();
    }

}
