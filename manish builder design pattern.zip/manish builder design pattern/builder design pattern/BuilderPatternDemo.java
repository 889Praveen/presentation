

public class BuilderPatternDemo {
    public static void main(String[] args) {
        SDLCBuilder builder = new SDLCBuilderImpl();
        SDLCDirector director = new SDLCDirector(builder);

    
        SoftwareProject project = director.withoutDesign();

        System.out.println(project);
    }
}