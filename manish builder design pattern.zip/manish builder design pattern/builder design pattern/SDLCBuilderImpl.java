class SDLCBuilderImpl implements SDLCBuilder {
    private SoftwareProject project;

    public SDLCBuilderImpl() {
        this.project = new SoftwareProject();
    }

    @Override
    public void setRequirements(String requirements) {
        project.setRequirements(requirements);
    }

    @Override
    public void setDesign(String design) {
        project.setDesign(design);
    }

    @Override
    public void setDevelopment(String development) {
        project.setDevelopment(development);
    }

    @Override
    public void setTesting(String testing) {
        project.setTesting(testing);
    }

    @Override
    public void setDeployment(String deployment) {
        project.setDeployment(deployment);
    }

    @Override
    public SoftwareProject build() {
        return this.project;
    }
}
